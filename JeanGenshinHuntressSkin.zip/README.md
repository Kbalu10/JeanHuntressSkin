Risk of Rain 2 Mod Jean Gunnhildr 
Work In Progress (But works)
I do not own ANY of the models, HoYoVerse owns all these models.
***Updated for SoTS***

This work is based on "Genshin Impact: Jean" (https://sketchfab.com/3d-models/genshin-impact-jean-a4b663c7015e4976a894437944bf9649) by Alqueit (https://sketchfab.com/Alqueit) licensed under CC-BY-4.0 (http://creativecommons.org/licenses/by/4.0/)

